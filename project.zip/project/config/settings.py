
import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

def _parse_owner_ids(raw: str | None) -> set[int]:
    if not raw:
        return set()
    ids: set[int] = set()
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            ids.add(int(part))
        except ValueError:
            pass
    return ids

def _db_path_from_url(url: str | None) -> str:
    default = "data/bot.db"
    if not url:
        return default
    if url.startswith("sqlite:///"):
        return url.replace("sqlite:///", "", 1)
    return url

@dataclass
class Settings:
    API_ID: int = int(os.getenv("API_ID", "0"))
    API_HASH: str = os.getenv("API_HASH", "")
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///data/bot.db")
    OWNER_IDS: set[int] = _parse_owner_ids(os.getenv("OWNER_IDS"))
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOCALE: str = os.getenv("LOCALE", "id")

    @property
    def DB_PATH(self) -> str:
        path = _db_path_from_url(self.DATABASE_URL)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        return path
