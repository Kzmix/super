
from bot.services.spam import SpamDetector, WINDOW_SEC
import time

def test_window_limit():
    s = SpamDetector()
    chat, user = 1, 10
    spam = False
    why = ""
    for i in range(6):
        spam, why = s.is_spam(chat, user, f"msg{i}", "low")
    assert spam

def test_identical_repeat():
    s = SpamDetector()
    chat, user = 1, 11
    spam, _ = s.is_spam(chat, user, "same", "med")
    spam, _ = s.is_spam(chat, user, "same", "med")
    assert spam

def test_window_decay():
    s = SpamDetector()
    chat, user = 1, 12
    for i in range(5):
        s.is_spam(chat, user, f"m{i}", "high")
    time.sleep(WINDOW_SEC + 1)
    spam, _ = s.is_spam(chat, user, "after", "high")
    assert not spam
