
import asyncio
import types
from bot.services.gate import GateService
from bot.services.membership import TTLCache

class DummyRepo:
    def __init__(self):
        self._s = types.SimpleNamespace(
            chat_id=1,
            gate_enabled=1,
            gate_target_id=123,
            gate_target="@test",
            gate_target_type="channel",
            spam_action="warn",
            warn_threshold=3,
            spam_sensitivity="med",
        )

    async def get_or_create_settings(self, chat_id):
        return self._s

class DummyEvent:
    def __init__(self, chat_id=1, user_id=2):
        self.chat_id = chat_id
        self.sender_id = user_id
        self._deleted = False

    async def delete(self):
        self._deleted = True

    async def respond(self, *_args, **_kwargs):
        pass

class DummyClient:
    async def get_permissions(self, target, user_id):
        return None

def test_gate_blocks_message():
    repo = DummyRepo()
    svc = GateService(repo, TTLCache(ttl=1))
    client = DummyClient()
    ev = DummyEvent()
    allowed = asyncio.get_event_loop().run_until_complete(svc.enforce(client, ev, repo._s))
    assert allowed is False
    assert ev._deleted is True
