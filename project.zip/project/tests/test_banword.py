
from bot.services.banword import BanwordMatcher

def test_plain_match():
    m = BanwordMatcher([("bad", 0)])
    assert m.check("this is bad text")
    assert m.check("BAD is here")
    assert m.check("b.ad") is None

def test_regex_match():
    m = BanwordMatcher([("b.+d", 1)])
    assert m.check("b123d")
    assert m.check("abcd")
    assert m.check("bbd") is None
