
from __future__ import annotations
import logging
import re
from telethon import events

logger = logging.getLogger(__name__)

class Middleware:
    def __init__(self, chat_repo, gate_service, spam_detector):
        self.chat_repo = chat_repo
        self.gate = gate_service
        self.spam = spam_detector

    async def handle_message(self, client, event: events.NewMessage.Event):
        if event.is_private:
            return
        if event.out:
            return
        text = event.raw_text or ""
        chat_id = event.chat_id
        user_id = event.sender_id

        if text.startswith("/"):
            return

        settings = await self.chat_repo.get_or_create_settings(chat_id)

        whitelisted = user_id in await self.chat_repo.list_whitelist(chat_id)
        if whitelisted:
            return

        allowed = await self.gate.enforce(client, event, settings)
        if not allowed:
            return

        blocked = await self.chat_repo.list_blocked_domains(chat_id)
        for d in blocked:
            if re.search(rf"https?://([^/]*\.)?{re.escape(d)}(/|$)", text, re.I):
                await self._act(client, event, settings, reason=f"Tautan ke domain terblokir: {d}")
                return

        from .services.banword import BanwordMatcher
        patterns = await self.chat_repo.list_banwords(chat_id)
        matcher = BanwordMatcher([(p["pattern"], p["is_regex"]) for p in patterns])
        hit = matcher.check(text)
        if hit:
            await self._act(client, event, settings, reason=f"Kata terlarang: {hit}")
            return

        spam, why = self.spam.is_spam(chat_id, user_id, text, settings.spam_sensitivity)
        if spam:
            await self._act(client, event, settings, reason=why)
            return

    async def _act(self, client, event, settings, reason: str):
        chat_id = event.chat_id
        user_id = event.sender_id
        try:
            await event.delete()
        except Exception:
            pass

        count = await self.chat_repo.increment_warning(chat_id, user_id)
        uname = getattr(event.sender, 'username', None)
        mention = f"@{uname}" if uname else str(user_id)
        await event.respond(f"⚠️ {mention}: {reason} (peringatan {count}/{settings.warn_threshold})")
        action = settings.spam_action
        if count < settings.warn_threshold and action != "warn":
            return

        try:
            if action == "mute":
                until = 10 * 60
                await client.edit_permissions(chat_id, user_id, send_messages=False, until_date=until)
                await event.respond("🔇 Pengguna dimute 10 menit.")
            elif action == "kick":
                await client.kick_participant(chat_id, user_id)
                await event.respond("👢 Pengguna dikeluarkan.")
            elif action == "ban":
                await client.edit_permissions(chat_id, user_id, view_messages=False)
                await event.respond("⛔ Pengguna diblokir.")
        except Exception as e:
            logger.warning("Failed to enforce action %s: %s", action, e)
