
from __future__ import annotations
import asyncio
import logging
import signal
from telethon import events
from config.settings import Settings
from .logging import setup_logging
from .loader import build
from .middleware import Middleware
from .handlers.common import register_common
from .handlers.admin_gate import register_gate
from .handlers.admin_banword import register_banword
from .handlers.admin_spam import register_spam
from .handlers.admin_whitelist import register_whitelist
from .handlers.admin_links import register_links
from .handlers.admin_welcome import register_welcome
from .handlers.admin_backup import register_backup
from .services.welcome import format_vars

async def main():
    settings = Settings()
    setup_logging(settings.LOG_LEVEL)
    ctx = await build()
    client = ctx.client

    mw = Middleware(ctx.repos.chat, ctx.services.gate, ctx.services.spam)
    client.add_event_handler(lambda e: mw.handle_message(client, e), events.NewMessage())

    register_common(client, ctx)
    register_gate(client, ctx)
    register_banword(client, ctx)
    register_spam(client, ctx)
    register_whitelist(client, ctx)
    register_links(client, ctx)
    register_welcome(client, ctx)
    register_backup(client, ctx)

    @client.on(events.CallbackQuery(pattern=b"reverify:(\-?\d+)"))
    async def _(event):
        chat_id = int(event.pattern_match.group(1).decode())
        s = await ctx.repos.chat.get_or_create_settings(chat_id)
        ok = await ctx.services.gate.enforce(client, event, s)
        if ok:
            await event.edit("✅ Verifikasi sukses. Kamu sudah bisa mengirim pesan.")
        else:
            await event.answer("Belum terdeteksi menjadi member.", alert=True)

    @client.on(events.ChatAction())
    async def _(event):
        if event.user_joined or event.user_added:
            s = await ctx.repos.chat.get_or_create_settings(event.chat_id)
            if s.welcome_enabled:
                text = await format_vars(s.welcome_text, event.user, await event.get_chat())
                await event.reply(text)
        elif event.user_left or event.user_kicked:
            s = await ctx.repos.chat.get_or_create_settings(event.chat_id)
            if s.goodbye_enabled:
                text = await format_vars(s.goodbye_text, event.user, await event.get_chat())
                await event.reply(text)

    stop_event = asyncio.Event()

    def _graceful(*_):
        logging.getLogger(__name__).info("Shutting down...")
        stop_event.set()

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _graceful)
        except NotImplementedError:
            pass

    await client.connect()
    await client.send_message("me", "✅ Bot started.")
    runner = asyncio.create_task(client.run_until_disconnected())
    await stop_event.wait()
    runner.cancel()
    await client.disconnect()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
