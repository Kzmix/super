
from dataclasses import dataclass
from typing import Optional

@dataclass
class ChatSettings:
    chat_id: int
    gate_enabled: int = 0
    gate_target: Optional[str] = None
    gate_target_type: Optional[str] = None
    gate_target_id: Optional[int] = None
    banword_action: str = "warn"
    warn_threshold: int = 3
    spam_sensitivity: str = "med"
    spam_action: str = "mute"
    welcome_enabled: int = 0
    welcome_text: str = "Selamat datang {first_name}! Selamat bergabung di {chat_title}."
    goodbye_enabled: int = 0
    goodbye_text: str = "Sampai jumpa, {first_name}!"
