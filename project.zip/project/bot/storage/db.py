
import aiosqlite
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

SCHEMA_SQL = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS chats (
  chat_id INTEGER PRIMARY KEY,
  gate_enabled INTEGER DEFAULT 0,
  gate_target TEXT,
  gate_target_type TEXT,
  gate_target_id INTEGER,
  banword_action TEXT DEFAULT 'warn',
  warn_threshold INTEGER DEFAULT 3,
  spam_sensitivity TEXT DEFAULT 'med',
  spam_action TEXT DEFAULT 'mute',
  welcome_enabled INTEGER DEFAULT 0,
  welcome_text TEXT,
  goodbye_enabled INTEGER DEFAULT 0,
  goodbye_text TEXT
);

CREATE TABLE IF NOT EXISTS banwords (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER,
  pattern TEXT NOT NULL,
  is_regex INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS whitelist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER,
  user_id INTEGER
);

CREATE TABLE IF NOT EXISTS links (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER,
  domain TEXT
);

CREATE TABLE IF NOT EXISTS warnings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chat_id INTEGER,
  user_id INTEGER,
  count INTEGER DEFAULT 0,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
  user_id INTEGER PRIMARY KEY,
  first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

async def init_db(path: str) -> aiosqlite.Connection:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = await aiosqlite.connect(path)
    conn.row_factory = aiosqlite.Row
    for stmt in filter(None, SCHEMA_SQL.split(";\n")):
        s = stmt.strip()
        if s:
            await conn.execute(s)
    await conn.commit()
    return conn
