
from __future__ import annotations
import aiosqlite
from .models import ChatSettings

class ChatRepo:
    def __init__(self, db: aiosqlite.Connection):
        self.db = db

    async def get_or_create_settings(self, chat_id: int) -> ChatSettings:
        row = await (await self.db.execute("SELECT * FROM chats WHERE chat_id=?", (chat_id,))).fetchone()
        if row:
            return ChatSettings(**row)
        await self.db.execute("INSERT OR IGNORE INTO chats(chat_id) VALUES(?)", (chat_id,))
        await self.db.commit()
        return ChatSettings(chat_id=chat_id)

    async def update_settings(self, chat_id: int, **fields) -> ChatSettings:
        if not fields:
            return await self.get_or_create_settings(chat_id)
        cols = ", ".join([f"{k}=?" for k in fields])
        vals = list(fields.values()) + [chat_id]
        await self.db.execute(f"UPDATE chats SET {cols} WHERE chat_id=?", vals)
        await self.db.commit()
        return await self.get_or_create_settings(chat_id)

    async def add_banword(self, chat_id: int, pattern: str, is_regex: int) -> None:
        await self.db.execute(
            "INSERT INTO banwords(chat_id, pattern, is_regex) VALUES(?,?,?)",
            (chat_id, pattern, is_regex),
        )
        await self.db.commit()

    async def remove_banword(self, chat_id: int, pattern: str) -> int:
        cur = await self.db.execute(
            "DELETE FROM banwords WHERE chat_id=? AND pattern=?", (chat_id, pattern)
        )
        await self.db.commit()
        return cur.rowcount

    async def list_banwords(self, chat_id: int):
        cur = await self.db.execute(
            "SELECT pattern, is_regex FROM banwords WHERE chat_id=? ORDER BY id DESC",
            (chat_id,),
        )
        return await cur.fetchall()

    async def add_whitelist(self, chat_id: int, user_id: int) -> None:
        await self.db.execute("INSERT INTO whitelist(chat_id, user_id) VALUES(?,?)", (chat_id, user_id))
        await self.db.commit()

    async def remove_whitelist(self, chat_id: int, user_id: int) -> int:
        cur = await self.db.execute("DELETE FROM whitelist WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        await self.db.commit()
        return cur.rowcount

    async def list_whitelist(self, chat_id: int) -> list[int]:
        cur = await self.db.execute("SELECT user_id FROM whitelist WHERE chat_id=?", (chat_id,))
        rows = await cur.fetchall()
        return [r[0] for r in rows]

    async def add_blocked_domain(self, chat_id: int, domain: str) -> None:
        await self.db.execute("INSERT INTO links(chat_id, domain) VALUES(?,?)", (chat_id, domain))
        await self.db.commit()

    async def remove_blocked_domain(self, chat_id: int, domain: str) -> int:
        cur = await self.db.execute("DELETE FROM links WHERE chat_id=? AND domain=?", (chat_id, domain))
        await self.db.commit()
        return cur.rowcount

    async def list_blocked_domains(self, chat_id: int) -> list[str]:
        cur = await self.db.execute("SELECT domain FROM links WHERE chat_id=?", (chat_id,))
        return [r[0] for r in await cur.fetchall()]

    async def increment_warning(self, chat_id: int, user_id: int) -> int:
        row = await (await self.db.execute(
            "SELECT id, count FROM warnings WHERE chat_id=? AND user_id=?", (chat_id, user_id)
        )).fetchone()
        if row:
            await self.db.execute("UPDATE warnings SET count=count+1, updated_at=CURRENT_TIMESTAMP WHERE id=?", (row["id"],))
            await self.db.commit()
            return int(row["count"]) + 1
        await self.db.execute("INSERT INTO warnings(chat_id, user_id, count) VALUES(?,?,1)", (chat_id, user_id))
        await self.db.commit()
        return 1

    async def reset_warnings(self, chat_id: int, user_id: int) -> None:
        await self.db.execute("DELETE FROM warnings WHERE chat_id=? AND user_id=?", (chat_id, user_id))
        await self.db.commit()

    async def get_warning_count(self, chat_id: int, user_id: int) -> int:
        row = await (await self.db.execute(
            "SELECT count FROM warnings WHERE chat_id=? AND user_id=?", (chat_id, user_id)
        )).fetchone()
        return int(row["count"]) if row else 0
