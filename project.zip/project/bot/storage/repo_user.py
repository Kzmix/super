
import aiosqlite

class UserRepo:
    def __init__(self, db: aiosqlite.Connection):
        self.db = db

    async def touch_user(self, user_id: int) -> None:
        await self.db.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)", (user_id,))
        await self.db.commit()
