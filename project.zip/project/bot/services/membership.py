
from __future__ import annotations
import time
from typing import Any, Dict, Tuple
from telethon.tl.custom import Button

class TTLCache:
    def __init__(self, ttl: int = 600, maxsize: int = 10000):
        self.ttl = ttl
        self.maxsize = maxsize
        self._data: Dict[Any, Tuple[float, Any]] = {}

    def get(self, key: Any):
        now = time.time()
        item = self._data.get(key)
        if not item:
            return None
        exp, val = item
        if exp < now:
            self._data.pop(key, None)
            return None
        return val

    def set(self, key: Any, val: Any):
        if len(self._data) > self.maxsize:
            self._data.pop(next(iter(self._data)))
        self._data[key] = (time.time() + self.ttl, val)

async def is_member(client, target, user_id: int, cache: TTLCache) -> bool:
    key = ("member", int(getattr(target, "id", target)), user_id)
    cached = cache.get(key)
    if cached is not None:
        return cached
    try:
        perms = await client.get_permissions(target, user_id)
        ok = bool(perms)
    except Exception:
        ok = False
    cache.set(key, ok)
    return ok

async def build_reverify_button(chat_id: int) -> list:
    return [[Button.inline("Saya sudah join, cek lagi", data=f"reverify:{chat_id}")]]
