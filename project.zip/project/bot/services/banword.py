
from __future__ import annotations
import logging
import re
from typing import Iterable

logger = logging.getLogger(__name__)

MAX_PATTERNS_PER_CHAT = 200
MAX_PATTERN_LEN = 120

class BanwordMatcher:
    def __init__(self, patterns: Iterable[tuple[str, int]]):
        self.compiled: list[tuple[re.Pattern, bool]] = []
        for pat, is_regex in patterns:
            if not pat:
                continue
            if len(pat) > MAX_PATTERN_LEN:
                continue
            try:
                if is_regex:
                    rx = re.compile(pat, re.IGNORECASE)
                    self.compiled.append((rx, True))
                else:
                    rx = re.compile(re.escape(pat), re.IGNORECASE)
                    self.compiled.append((rx, False))
            except re.error:
                logger.warning("Invalid regex ignored: %s", pat)

    def check(self, text: str) -> str | None:
        for rx, _ in self.compiled[:MAX_PATTERNS_PER_CHAT]:
            if rx.search(text or ""):
                return rx.pattern
        return None
