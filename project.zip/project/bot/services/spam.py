
from __future__ import annotations
import time
from collections import defaultdict, deque
import re

WINDOW_SEC = 5
LOW, MED, HIGH = (6, 5, 4)

class SpamDetector:
    def __init__(self):
        self.msg_window = defaultdict(lambda: deque(maxlen=20))
        self.last_text = {}

    def _limit_for(self, sensitivity: str) -> int:
        s = (sensitivity or "med").lower()
        return {"low": LOW, "med": MED, "high": HIGH}.get(s, MED)

    def is_spam(self, chat_id: int, user_id: int, text: str, sensitivity: str):
        now = time.time()
        dq = self.msg_window[(chat_id, user_id)]
        dq.append(now)
        while dq and now - dq[0] > WINDOW_SEC:
            dq.popleft()
        limit = self._limit_for(sensitivity)
        if len(dq) >= limit:
            return True, f"Terlalu banyak pesan ({len(dq)}/{limit}) dalam {WINDOW_SEC}s"

        key = (chat_id, user_id)
        last = self.last_text.get(key)
        if last and text and text == last:
            return True, "Pesan identik berulang"
        self.last_text[key] = text

        if text:
            non_alnum = len(re.findall(r"[^\w\s]", text))
            if non_alnum >= 10 and non_alnum > len(text) / 2:
                return True, "Karakter non-alfanumerik berlebihan"

        links = re.findall(r"https?://\S+", text or "")
        if len(links) >= 3:
            return True, "Terlalu banyak tautan dalam satu pesan"

        return False, ""
