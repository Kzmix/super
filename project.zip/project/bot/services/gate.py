
from __future__ import annotations
import logging
from .membership import is_member, TTLCache, build_reverify_button

logger = logging.getLogger(__name__)

class GateService:
    def __init__(self, chat_repo, cache: TTLCache | None = None):
        self.chat_repo = chat_repo
        self.cache = cache or TTLCache(ttl=600)

    async def enforce(self, client, event, settings) -> bool:
        if not settings.gate_enabled:
            return True
        if not settings.gate_target_id:
            return True
        try:
            ok = await is_member(client, int(settings.gate_target_id), event.sender_id, self.cache)
        except Exception:
            ok = False
        if ok:
            return True
        try:
            await event.delete()
        except Exception:
            pass
        try:
            buttons = await build_reverify_button(event.chat_id)
            await event.respond(
                "Anda harus bergabung dengan target terlebih dahulu sebelum bisa mengirim pesan di sini.",
                buttons=buttons,
            )
        except Exception:
            pass
        return False

    async def set_target(self, chat_id: int, target: str, target_type: str, target_id: int):
        await self.chat_repo.update_settings(
            chat_id,
            gate_target=target,
            gate_target_type=target_type,
            gate_target_id=target_id,
        )
