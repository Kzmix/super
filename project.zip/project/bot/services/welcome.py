
from __future__ import annotations

async def format_vars(text: str, user, chat) -> str:
    return (text or "").format(
        first_name=(user.first_name or user.username or "teman"),
        id=user.id,
        chat_title=getattr(chat, "title", "group"),
    )
