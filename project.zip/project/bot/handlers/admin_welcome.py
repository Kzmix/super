
from __future__ import annotations
from telethon import events
from .admin_gate import _is_admin

def register_welcome(client, ctx):
    @client.on(events.NewMessage(pattern=r"^/welcome_set\s+(.+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        txt = event.pattern_match.group(1)
        await ctx.repos.chat.update_settings(event.chat_id, welcome_text=txt)
        await event.respond("Welcome text disimpan.")

    @client.on(events.NewMessage(pattern=r"^/welcome_on$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        await ctx.repos.chat.update_settings(event.chat_id, welcome_enabled=1)
        await event.respond("Welcome diaktifkan.")

    @client.on(events.NewMessage(pattern=r"^/welcome_off$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        await ctx.repos.chat.update_settings(event.chat_id, welcome_enabled=0)
        await event.respond("Welcome dimatikan.")

    @client.on(events.NewMessage(pattern=r"^/goodbye_set\s+(.+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        txt = event.pattern_match.group(1)
        await ctx.repos.chat.update_settings(event.chat_id, goodbye_text=txt)
        await event.respond("Goodbye text disimpan.")

    @client.on(events.NewMessage(pattern=r"^/goodbye_on$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        await ctx.repos.chat.update_settings(event.chat_id, goodbye_enabled=1)
        await event.respond("Goodbye diaktifkan.")

    @client.on(events.NewMessage(pattern=r"^/goodbye_off$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        await ctx.repos.chat.update_settings(event.chat_id, goodbye_enabled=0)
        await event.respond("Goodbye dimatikan.")
