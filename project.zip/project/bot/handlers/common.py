
from __future__ import annotations
import asyncio
from telethon import events
from bot import __version__

HELP_TEXT = (
    "Halo! Aku asisten moderasi multi-tenant berbasis Telethon.\n\n"
    "Fitur utama: Gate join, filter kata, anti-spam/flood, whitelist/blacklist, welcome/goodbye, backup & impor.\n\n"
    "Perintah umum:\n"
    "/start, /help, /ping, /version, /config\n\n"
    "Perintah admin (per chat):\n"
    "/gate_on | /gate_off | /gate_target <link|@user|id> | /gate_status\n"
    "/banword_add <kata/regex> | /banword_remove <kata> | /banword_list\n"
    "/spam_sensitivity <low|med|high> | /spam_action <warn|mute|kick|ban> | /spam_status\n"
    "/whitelist_add <@user|id> | /whitelist_remove <@user|id> | /whitelist_list\n"
    "/blocklink_add <domain> | /blocklink_remove <domain> | /blocklink_list\n"
    "/welcome_set <text> | /welcome_on | /welcome_off\n"
    "/goodbye_set <text> | /goodbye_on | /goodbye_off\n"
    "/backup | /import (reply file JSON)\n\n"
    "Owner global:\n"
    "/global_stats | /global_chats | /global_broadcast <text> | /global_backup\n\n"
    "Privacy: Bot menyimpan konfigurasi minimal per chat di SQLite.\n"
)

def register_common(client, ctx):
    @client.on(events.NewMessage(pattern=r"^/(start|help)$"))
    async def _(event):
        await event.respond(HELP_TEXT)

    @client.on(events.NewMessage(pattern=r"^/ping$"))
    async def _(event):
        msg = await event.respond("Pong...")
        await asyncio.sleep(0.3)
        await msg.edit("🏓 Pong!")

    @client.on(events.NewMessage(pattern=r"^/version$"))
    async def _(event):
        from telethon import __version__ as tv
        await event.respond(f"Bot v{__version__} | Telethon {tv}")

    @client.on(events.NewMessage(pattern=r"^/config$"))
    async def _(event):
        s = await ctx.repos.chat.get_or_create_settings(event.chat_id)
        txt = (
            f"Konfigurasi ringkas:\n"
            f"• Gate: {'ON' if s.gate_enabled else 'OFF'} | Target: {s.gate_target or '-'}\n"
            f"• Spam: sensitivity={s.spam_sensitivity} action={s.spam_action}\n"
            f"• Banword: {len(await ctx.repos.chat.list_banwords(event.chat_id))} item\n"
            f"• Welcome: {'ON' if s.welcome_enabled else 'OFF'}\n"
        )
        await event.respond(txt)
