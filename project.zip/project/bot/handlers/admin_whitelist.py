
from __future__ import annotations
from telethon import events
from .admin_gate import _is_admin

def _parse_user_id(raw: str) -> int | None:
    raw = raw.strip()
    if raw.startswith("@"):
        return None
    try:
        return int(raw)
    except Exception:
        return None

def register_whitelist(client, ctx):
    @client.on(events.NewMessage(pattern=r"^/whitelist_add\s+(.+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        raw = event.pattern_match.group(1)
        uid = _parse_user_id(raw)
        if uid is None:
            try:
                entity = await client.get_entity(raw)
                uid = int(entity.id)
            except Exception:
                await event.respond("Tidak bisa resolve user.")
                return
        await ctx.repos.chat.add_whitelist(event.chat_id, uid)
        await event.respond(f"Whitelisted: {uid}")

    @client.on(events.NewMessage(pattern=r"^/whitelist_remove\s+(.+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        raw = event.pattern_match.group(1)
        uid = _parse_user_id(raw)
        if uid is None:
            try:
                entity = await client.get_entity(raw)
                uid = int(entity.id)
            except Exception:
                await event.respond("Tidak bisa resolve user.")
                return
        n = await ctx.repos.chat.remove_whitelist(event.chat_id, uid)
        await event.respond(f"Whitelist dihapus: {uid} ({n})")

    @client.on(events.NewMessage(pattern=r"^/whitelist_list$"))
    async def _(event):
        items = await ctx.repos.chat.list_whitelist(event.chat_id)
        await event.respond("Whitelist:\n" + "\n".join([f"- {i}" for i in items]) if items else "(kosong)")
