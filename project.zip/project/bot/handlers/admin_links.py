
from __future__ import annotations
from telethon import events
from .admin_gate import _is_admin

def register_links(client, ctx):
    @client.on(events.NewMessage(pattern=r"^/blocklink_add\s+([A-Za-z0-9.-]+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        domain = event.pattern_match.group(1).lower()
        await ctx.repos.chat.add_blocked_domain(event.chat_id, domain)
        await event.respond(f"Domain diblokir: {domain}")

    @client.on(events.NewMessage(pattern=r"^/blocklink_remove\s+([A-Za-z0-9.-]+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        domain = event.pattern_match.group(1).lower()
        n = await ctx.repos.chat.remove_blocked_domain(event.chat_id, domain)
        await event.respond(f"Domain dihapus: {domain} ({n})")

    @client.on(events.NewMessage(pattern=r"^/blocklink_list$"))
    async def _(event):
        items = await ctx.repos.chat.list_blocked_domains(event.chat_id)
        await event.respond("Blocked domains:\n" + "\n".join([f"- {i}" for i in items]) if items else "(kosong)")
