
from __future__ import annotations
from telethon import events
from .admin_gate import _is_admin

def register_spam(client, ctx):
    @client.on(events.NewMessage(pattern=r"^/spam_sensitivity\s+(low|med|high)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        level = event.pattern_match.group(1)
        await ctx.repos.chat.update_settings(event.chat_id, spam_sensitivity=level)
        await event.respond(f"Spam sensitivity diset ke {level}.")

    @client.on(events.NewMessage(pattern=r"^/spam_action\s+(warn|mute|kick|ban)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        action = event.pattern_match.group(1)
        await ctx.repos.chat.update_settings(event.chat_id, spam_action=action)
        await event.respond(f"Spam action diset ke {action}.")

    @client.on(events.NewMessage(pattern=r"^/spam_status$"))
    async def _(event):
        s = await ctx.repos.chat.get_or_create_settings(event.chat_id)
        await event.respond(f"Spam: sensitivity={s.spam_sensitivity}, action={s.spam_action}")
