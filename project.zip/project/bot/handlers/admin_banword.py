
from __future__ import annotations
from telethon import events
from .admin_gate import _is_admin

def register_banword(client, ctx):
    @client.on(events.NewMessage(pattern=r"^/banword_add\s+(.+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        raw = event.pattern_match.group(1).strip()
        is_regex = 1 if (raw.startswith("/") and raw.endswith("/") and len(raw) >= 2) else 0
        pat = raw[1:-1] if is_regex else raw
        if len(pat) > 120:
            await event.respond("Pola terlalu panjang (maks 120).")
            return
        await ctx.repos.chat.add_banword(event.chat_id, pat, is_regex)
        await event.respond(f"Ditambahkan: {pat} ({'regex' if is_regex else 'plain'})")

    @client.on(events.NewMessage(pattern=r"^/banword_remove\s+(.+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        pat = event.pattern_match.group(1).strip()
        n = await ctx.repos.chat.remove_banword(event.chat_id, pat)
        await event.respond(f"Dihapus {n} entri untuk: {pat}")

    @client.on(events.NewMessage(pattern=r"^/banword_list$"))
    async def _(event):
        items = await ctx.repos.chat.list_banwords(event.chat_id)
        if not items:
            await event.respond("(kosong)")
        else:
            lines = [f"- {'/' + r['pattern'] + '/' if r['is_regex'] else r['pattern']}" for r in items]
            await event.respond("Banword:\n" + "\n".join(lines))
