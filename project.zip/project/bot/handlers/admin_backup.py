
from __future__ import annotations
import json
from telethon import events, Button
from .admin_gate import _is_admin

def register_backup(client, ctx):
    @client.on(events.NewMessage(pattern=r"^/backup$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        s = await ctx.repos.chat.get_or_create_settings(event.chat_id)
        data = {
            "chat_id": s.chat_id,
            "settings": s.__dict__,
            "banwords": [dict(pattern=r["pattern"], is_regex=r["is_regex"]) for r in await ctx.repos.chat.list_banwords(event.chat_id)],
            "whitelist": await ctx.repos.chat.list_whitelist(event.chat_id),
            "blocked_domains": await ctx.repos.chat.list_blocked_domains(event.chat_id),
        }
        raw = json.dumps(data, ensure_ascii=False, indent=2)
        await client.send_file(event.chat_id, file=raw.encode(), caption="Backup konfigurasi chat", force_document=True, file_name=f"backup_{event.chat_id}.json")

    @client.on(events.NewMessage(pattern=r"^/import$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        if not event.is_reply:
            await event.respond("Reply ke file JSON backup.")
            return
        msg = await event.get_reply_message()
        if not msg or not msg.file or not (msg.file.name or "").endswith('.json'):
            await event.respond("File tidak valid.")
            return
        raw = await msg.download_media(bytes)
        try:
            data = json.loads(raw.decode())
        except Exception:
            await event.respond("JSON invalid.")
            return
        await event.respond("Impor konfigurasi? Ini akan menimpa pengaturan saat ini.",
                            buttons=[[Button.inline("Lanjutkan impor", data=f"import:{event.chat_id}")]])
        ctx.pending_import[event.chat_id] = data

    @client.on(events.CallbackQuery(pattern=b"import:(\-?\d+)"))
    async def _(event):
        chat_id = int(event.pattern_match.group(1).decode())
        if chat_id != event.chat_id:
            return
        data = ctx.pending_import.pop(chat_id, None)
        if not data:
            await event.answer("Tidak ada data.", alert=True)
            return
        s = data.get("settings", {})
        await ctx.repos.chat.update_settings(chat_id, **{k: v for k, v in s.items() if k != "chat_id"})
        for r in await ctx.repos.chat.list_banwords(chat_id):
            await ctx.repos.chat.remove_banword(chat_id, r["pattern"])
        for item in data.get("banwords", []):
            await ctx.repos.chat.add_banword(chat_id, item.get("pattern", ""), int(item.get("is_regex", 0)))
        for uid in await ctx.repos.chat.list_whitelist(chat_id):
            await ctx.repos.chat.remove_whitelist(chat_id, uid)
        for uid in data.get("whitelist", []):
            await ctx.repos.chat.add_whitelist(chat_id, int(uid))
        for d in await ctx.repos.chat.list_blocked_domains(chat_id):
            await ctx.repos.chat.remove_blocked_domain(chat_id, d)
        for d in data.get("blocked_domains", []):
            await ctx.repos.chat.add_blocked_domain(chat_id, d)
        await event.edit("Impor selesai.")

    @client.on(events.NewMessage(pattern=r"^/global_stats$"))
    async def _(event):
        if event.sender_id not in ctx.settings.OWNER_IDS:
            return
        cur = await ctx.db.execute("SELECT COUNT(*) as c FROM chats")
        chats = (await cur.fetchone())[0]
        cur = await ctx.db.execute("SELECT COUNT(*) as c FROM users")
        users = (await cur.fetchone())[0]
        await event.respond(f"Global stats: chats={chats}, users={users}")

    @client.on(events.NewMessage(pattern=r"^/global_chats$"))
    async def _(event):
        if event.sender_id not in ctx.settings.OWNER_IDS:
            return
        cur = await ctx.db.execute("SELECT chat_id FROM chats ORDER BY chat_id DESC LIMIT 50")
        ids = [str(r[0]) for r in await cur.fetchall()]
        await event.respond("Chats terakhir:\n" + "\n".join(ids))

    @client.on(events.NewMessage(pattern=r"^/global_broadcast\s+(.+)$"))
    async def _(event):
        if event.sender_id not in ctx.settings.OWNER_IDS:
            return
        text = event.pattern_match.group(1)
        cur = await ctx.db.execute("SELECT chat_id FROM chats")
        chats = [r[0] for r in await cur.fetchall()]
        for cid in chats:
            try:
                await client.send_message(cid, f"[Broadcast]\n{text}")
            except Exception:
                pass
        await event.respond(f"Broadcast terkirim ke {len(chats)} chat.")

    @client.on(events.NewMessage(pattern=r"^/global_backup$"))
    async def _(event):
        if event.sender_id not in ctx.settings.OWNER_IDS:
            return
        await client.send_file(event.chat_id, ctx.settings.DB_PATH, caption="Database backup (manual restore).")
