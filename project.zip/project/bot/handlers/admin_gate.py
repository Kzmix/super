
from __future__ import annotations
from telethon import events

async def _is_admin(client, chat_id: int, user_id: int) -> bool:
    try:
        p = await client.get_permissions(chat_id, user_id)
        return bool(p) and (p.is_admin or p.is_creator)
    except Exception:
        return False

def register_gate(client, ctx):
    @client.on(events.NewMessage(pattern=r"^/gate_on$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        await ctx.repos.chat.update_settings(event.chat_id, gate_enabled=1)
        await event.respond("Gate diaktifkan.")

    @client.on(events.NewMessage(pattern=r"^/gate_off$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        await ctx.repos.chat.update_settings(event.chat_id, gate_enabled=0)
        await event.respond("Gate dimatikan.")

    @client.on(events.NewMessage(pattern=r"^/gate_status$"))
    async def _(event):
        s = await ctx.repos.chat.get_or_create_settings(event.chat_id)
        await event.respond(f"Gate: {'ON' if s.gate_enabled else 'OFF'} | Target: {s.gate_target or '-'}")

    @client.on(events.NewMessage(pattern=r"^/gate_target\s+(.+)$"))
    async def _(event):
        if not await _is_admin(client, event.chat_id, event.sender_id):
            return
        raw = event.pattern_match.group(1).strip()
        try:
            entity = await client.get_entity(raw)
            target_id = int(entity.id)
            target_type = "channel" if getattr(entity, "broadcast", False) else "group"
            await ctx.services.gate.set_target(event.chat_id, raw, target_type, target_id)
            await event.respond(f"Gate target diset ke {raw} ({target_type}).")
        except Exception as e:
            await event.respond(f"Gagal resolve target: {e}")
