
from __future__ import annotations
from dataclasses import dataclass
from telethon import TelegramClient
from config.settings import Settings
from bot.storage.db import init_db
from bot.storage.repo_chat import ChatRepo
from bot.storage.repo_user import UserRepo
from bot.services.gate import GateService
from bot.services.membership import TTLCache
from bot.services.spam import SpamDetector

@dataclass
class Repos:
    chat: ChatRepo
    user: UserRepo

@dataclass
class Ctx:
    client: TelegramClient
    db: any
    settings: Settings
    repos: Repos
    services: any
    pending_import: dict

async def build() -> Ctx:
    settings = Settings()
    client = TelegramClient("bot", settings.API_ID, settings.API_HASH)
    await client.start(bot_token=settings.BOT_TOKEN)

    db = await init_db(settings.DB_PATH)
    repos = Repos(ChatRepo(db), UserRepo(db))

    services = type("_S", (), {})()
    services.gate = GateService(repos.chat, TTLCache(ttl=600))
    services.spam = SpamDetector()

    return Ctx(client=client, db=db, settings=settings, repos=repos, services=services, pending_import={})
