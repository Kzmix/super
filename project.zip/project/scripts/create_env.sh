
#!/data/data/com.termux/files/usr/bin/bash
set -e
if [ -f .env ]; then echo ".env already exists"; exit 0; fi
cp config/.env.example .env
sed -i 's/API_ID=.*/API_ID=YOUR_ID/' .env
sed -i 's/API_HASH=.*/API_HASH=YOUR_HASH/' .env
sed -i 's/BOT_TOKEN=.*/BOT_TOKEN=YOUR_BOT_TOKEN/' .env
echo "Created .env (edit it to fill your credentials)"
