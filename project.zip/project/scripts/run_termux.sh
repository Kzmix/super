
#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
export PYTHONUNBUFFERED=1
python -m bot.main
