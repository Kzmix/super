
# Telethon Group Assistant (Multi-Tenant, Termux-ready)

Asisten moderasi & utilitas untuk grup/channel Telegram berbasis **Telethon**, siap jalan di **Termux Android**.

## Instalasi Termux (Singkat)
```bash
pkg update -y
pkg install -y python git openssl libffi
pip install --upgrade pip wheel

# ambil project ini (unduh ZIP dari chat lalu ekstrak)
unzip telethon-bot-project.zip -d bot-telethon
cd bot-telethon/project
pip install -r requirements.txt

cp config/.env.example .env
# isi API_ID, API_HASH, BOT_TOKEN, OWNER_IDS
python -m bot.main
```

Perintah admin & fitur lengkap ada di dokumentasi chat ini.
